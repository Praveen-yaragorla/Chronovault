import requests
import json
from datetime import datetime
import os

def get_url():
    return "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd"

def main():
    url = get_url()
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S")

        # Print all information
        print(f"Snapshot taken at: {timestamp}")
        print(f"Bitcoin Price (USD): ${data['bitcoin']['usd']}")

        # Save to file
        data['snapshot_time'] = timestamp
        safe_filename = f"btc_snapshot_{timestamp.replace(':', '-').replace(' ', '_')}.json"
        folder = "../data"
        os.makedirs(folder, exist_ok=True)
        filepath = os.path.join(folder, safe_filename)
        with open(filepath, "w") as f:
            json.dump(data, f, indent=4)

        print(f"Data saved to {filepath}")

    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()